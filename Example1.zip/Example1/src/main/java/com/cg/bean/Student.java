package com.cg.bean;

import java.util.*;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
//@SequenceGenerator(name="seq", initialValue=1,allocationSize=100)
@Document
public class Student {
	//@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@Id
	private String id;

	@NotNull
	@Size(min = 4, message = "Name should have atleast four letters")
	private String name;

	private Map<String, String> subjects = new HashMap<String, String>();

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(
			String id,
			@NotNull @Size(min = 4, message = "Name should have atleast four letters") String name,
			Map<String, String> subjects) {
		super();
		this.id = id;
		this.name = name;
		this.subjects = subjects;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String, String> getSubjects() {
		return subjects;
	}

	public void setSubjects(Map<String, String> subjects) {
		this.subjects = subjects;
	}

}
