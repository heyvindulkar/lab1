package com.cg.dao;

import java.util.List;

import javax.validation.Valid;

import com.cg.bean.Student;

public interface IDao {

	Student addStudent(@Valid Student student);

	Student deleteStudent(String id);

	Student getStudentById(String id);

	List<Student> getAllStudents();

	Student updateStudent(Student student);

}
