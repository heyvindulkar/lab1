package com.cg.expenseclaimdetailsmodule.bean;

import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;



import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonFormat;


public class Employee {
	
	@Id
	//@GeneratedValue( strategy = GenerationType.IDENTITY)
	private String empId;
	@NotNull
	@Pattern(regexp="^[a-zA-Z0-9_ ]*$",message="Empname start with capital letter")
	private String empName;
	
	@NotNull
	@Pattern(regexp="[A-Z]{1}[a-z0-9]{9}",message="Pan number should be 10")
	private String empPan;
	
	@NotNull
	@Pattern(regexp="^[A-Z]{1}[A-Za-z0-9_ ]*$",message="Designation start with capital letter")
	private String empDesignation;
	
	@NotNull
	@Pattern(regexp="^[A-Z]{1}[A-Za-z0-9_ ]*$",message="Domain should contain only letter")
	private String empDomain;
	
	@NotNull
	@JsonFormat(pattern="dd-MM-yyyy")
	private Date empDoj;
	
	@NotNull
	@JsonFormat(pattern="dd-MM-yyyy")
	private Date empDob;
	
	@NotNull
	@Pattern(regexp="^(.*)@(.*)$",message="Not a valid email")
	private String empEmail;
	
	@NotNull
	@Pattern(regexp="[1-9]{1}[0-9]{4}",message="Give a vaild salary")
	private String empSalary ;
	
	@NotNull
	//@Pattern(regexp="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).{4,8}$",message="Password minimum should be 3 ")
	private String empPassword;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(String empId, String empName, String empPan,
			String empDesignation, String empDomain, Date empDoj, Date empDob,
			String empSalary, String empEmail, String empPassword) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empPan = empPan;
		this.empDesignation = empDesignation;
		this.empDomain = empDomain;
		this.empDoj = empDoj;
		this.empDob = empDob;
		this.empSalary = empSalary;
		this.empEmail = empEmail;
		this.empPassword = empPassword;
	}
	public String getempId() {
		return empId;
	}
	public void setempId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpPan() {
		return empPan;
	}
	public void setEmpPan(String empPan) {
		this.empPan = empPan;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public String getEmpDomain() {
		return empDomain;
	}
	public void setEmpDomain(String empDomain) {
		this.empDomain = empDomain;
	}
	public Date getEmpDoj() {
		return empDoj;
	}
	public void setEmpDoj(Date empDoj) {
		this.empDoj = empDoj;
	}
	public Date getEmpDob() {
		return empDob;
	}
	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}
	public String getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(String empSalary) {
		this.empSalary = empSalary;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpPassword() {
		return empPassword;
	}
	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}
	
	
	
}
