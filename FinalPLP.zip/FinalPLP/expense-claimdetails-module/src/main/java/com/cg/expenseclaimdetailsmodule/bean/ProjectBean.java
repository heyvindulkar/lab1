package com.cg.expenseclaimdetailsmodule.bean;

import java.util.Date;



import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonFormat;
public class ProjectBean {
	
	@Id
	private String projectCode;
	private String projectDesc;
	
	@JsonFormat(pattern="dd-MM-yyyy")
	private Date startDate;
	
	@JsonFormat(pattern="dd-MM-yyyy")
	private Date endDate;
	public ProjectBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProjectBean(String projectCode, String projectDesc, Date startDate,
			Date endDate) {
		super();
		this.projectCode = projectCode;
		this.projectDesc = projectDesc;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public String getProjectDesc() {
		return projectDesc;
	}
	public void setProjectDesc(String projectDesc) {
		this.projectDesc = projectDesc;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	

}
