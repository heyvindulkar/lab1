/*package com.cg.expensemodule.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.expensemodule.bean.ExpenseModule;

public interface ExpenseRepository extends JpaRepository<ExpenseModule, String> {
	
	

	
}
*/