package com.cg.expensemodule.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.expensemodule.bean.ExpenseModule;
import com.cg.expensemodule.dao.IExpenseDao;

@Service
public class ExpenseServiceImpl implements IExpenseService{
	@Autowired
	IExpenseDao dao;

	@Override
	public ExpenseModule createExpenseModule(ExpenseModule expense) {
		// TODO Auto-generated method stub
		return dao.createExpenseModule(expense);
	}

	@Override
	public List<ExpenseModule> readExpenseModule() {
		// TODO Auto-generated method stub
		return dao.readExpenseModule();
	}

	@Override
	public ExpenseModule deleteExpenseModule(String expenseCode) {
		// TODO Auto-generated method stub
		return dao.deleteExpenseModule(expenseCode);
	}

	@Override
	public ExpenseModule updateExpenseModule(String expenseCode,
			ExpenseModule expenseModule) {
		// TODO Auto-generated method stub
		return dao.updateExpenseModule(expenseCode,expenseModule);
	}

	@Override
	public ExpenseModule readExpenseModuleById(String expenseCode) {
		// TODO Auto-generated method stub
		return dao.readExpenseModuleById(expenseCode);
	}

}
