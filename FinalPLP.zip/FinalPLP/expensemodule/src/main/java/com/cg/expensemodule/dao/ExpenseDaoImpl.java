package com.cg.expensemodule.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.expensemodule.bean.ExpenseModule;

@Repository
public class ExpenseDaoImpl implements IExpenseDao {
	@Autowired
	MongoTemplate mongo;
	
	@Override
	public ExpenseModule createExpenseModule(ExpenseModule expense) {
		// TODO Auto-generated method stub
		mongo.save(expense);
		return expense;
	}

	@Override
	public List<ExpenseModule> readExpenseModule() {
		// TODO Auto-generated method stub
		return mongo.findAll(ExpenseModule.class);
	}

	@Override
	public ExpenseModule deleteExpenseModule(String expenseCode) {
		Query query=new Query();
		query.addCriteria(Criteria.where("expenseCode").is(expenseCode));
		ExpenseModule expenseModule =mongo.findOne(query, ExpenseModule.class);
		 mongo.remove(expenseModule);
		 return expenseModule;
		
		
	}

	@Override
	public ExpenseModule updateExpenseModule(String expenseCode, ExpenseModule expenseModule) {
	
		Query query=new Query();
		query.addCriteria(Criteria.where("expenseCode").is(expenseCode));
		mongo.findOne(query, ExpenseModule.class);
		expenseModule.setExpenseCode(expenseCode);
		mongo.save(expenseModule);
		return expenseModule;
		
	}

	@Override
	public ExpenseModule readExpenseModuleById(String expenseCode) {
		Query query=new Query();
		query.addCriteria(Criteria.where("expenseCode").is(expenseCode));
		return mongo.findOne(query, ExpenseModule.class);
	}

}
